"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(805);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./components/Card.js


function Card({ title , tags , thumbnail  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "card-item",
        style: {
            backgroundImage: "url(" + thumbnail.url + ")"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "card-item-wrapper"
        })
    });
}
/* harmony default export */ const components_Card = (Card);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
;// CONCATENATED MODULE: ./components/Section.js




function Section({ genre , videos  }) {
    console.log(videos);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "section",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                children: genre
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "video-items",
                children: videos.map((video)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: `/video/${video.slug}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Card, {
                            title: video.title,
                            tags: video.tags,
                            thumbnail: video.thumbnail
                        })
                    }, video.id)
                )
            })
        ]
    });
}
/* harmony default export */ const components_Section = (Section);

;// CONCATENATED MODULE: external "next/Link"
const Link_namespaceObject = require("next/Link");
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_namespaceObject);
;// CONCATENATED MODULE: external "next/Image"
const Image_namespaceObject = require("next/Image");
var Image_default = /*#__PURE__*/__webpack_require__.n(Image_namespaceObject);
;// CONCATENATED MODULE: ./public/disney.png
/* harmony default export */ const disney = ({"src":"/_next/static/media/disney.12178cc2.png","height":417,"width":1000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAAOklEQVR42gXAIQ5AUAAG4D9RbbpNUEx3hVcVZ3AB1QSS5MLf3mK2K06DaCQml8Pvdfs80VoteqPOplQKnh4pCZJxEgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/NavBar.js





function NavBar({ account  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "navbar",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                href: "/",
                children: /*#__PURE__*/ jsx_runtime_.jsx((Image_default()), {
                    src: disney,
                    alt: "Disney Logo",
                    width: 100,
                    height: 40
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "account-info",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Welcome ",
                            account?.username
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "avatar",
                        src: account?.avatar.url
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const components_NavBar = (NavBar);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
;// CONCATENATED MODULE: ./public/aladin.webp
/* harmony default export */ const aladin = ({"src":"/_next/static/media/aladin.c6b85b28.webp","height":878,"width":2048,"blurDataURL":"data:image/webp;base64,UklGRkIAAABXRUJQVlA4IDYAAACwAQCdASoIAAMAAkA4JYwCdAD0gbJgAP719dOZvVfToWGDw5bJbgTIbyUF+KAq9XmU1b4AAAA="});
;// CONCATENATED MODULE: ./pages/index.js







const getStaticProps = async ()=>{
    const url = "https://api-eu-central-1.graphcms.com/v2/cl3kcl26j9yxq01xp3effae70/master";
    const client = new external_graphql_request_.GraphQLClient(url, {
        headers: {
            authorization: "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImdjbXMtbWFpbi1wcm9kdWN0aW9uIn0.eyJ2ZXJzaW9uIjozLCJpYXQiOjE2NTM0MjMyNzIsImF1ZCI6WyJodHRwczovL2FwaS1ldS1jZW50cmFsLTEuZ3JhcGhjbXMuY29tL3YyL2NsM2tjbDI2ajl5eHEwMXhwM2VmZmFlNzAvbWFzdGVyIiwiaHR0cHM6Ly9tYW5hZ2VtZW50LW5leHQuZ3JhcGhjbXMuY29tIl0sImlzcyI6Imh0dHBzOi8vbWFuYWdlbWVudC5ncmFwaGNtcy5jb20vIiwic3ViIjoiYjcyOGUzZWQtZjQxNC00NWQ5LWFlZTktNGRiNzA1OTdiYWE2IiwianRpIjoiY2wza2xpeTZhYXBvbTAxemQ1dDV0M3IxNyJ9.qRNLVObhps7GDP2Y4FaIoAS5LU0wtNc6J3rORLCpJCWDBPR-VBedGgfvpt4U6YbUW5IQChykungovf1kCNEI-_F4T8A7Ne6APAPPauYHJ4pdX-pU5yQPqfc735795Kfb9kQSDX6zy5zE0b_Nu9BxrR6m7ySGcXmN0pz--la5LFxFUk64q4H6maoDI1nKqDgE4t6UPJ_4IphZUdE3RyYDwMSPbWuwBhD-Zr_vRGtiAMCM1hK_OxrOIU2DwdpfgJMiBC5m4FB81-0P_z4Dhuh4CIfwPhifzV85GkDF13sdCcvDZxnn8I3BWE_61lmrb0pQae_mch3rszbwZqaE_G22XeI-II-D8aToVi0BZgtsGOK3ypHNYhQWYtJdWpK3WJr0mENEfFGTWrs5StgrhWh4e9US-fQFTDG0QFT-3mTcqT5K5ezA9nR8MIyRyaTrLJ_Uv8RwLNWOt8BOq1allZSzQkpFZ3ndeEtPzGSPba-jcuIzdDtZF1E0Oj-Pt1AjWxGAu1fP5UqJeHPJpW03eEanj9vLllTgJwApgFc1vAOKYPGxrIR8GpQf1cnsfXS_rqI9HNIVw6Dd_QIXmVW3QsqmZ-uREn82fBN8UTO19G4vAnvHbRDRNlxUJ3UnFJP7xX20zYsSGmm2Eq6Ec2TvP5eKeVICi2xGhRHp2NAHEs3_63Y"
        }
    });
    const videosQuery = external_graphql_request_.gql`
  query {
    videos {
      id,
      title,
      description,
      seen,
      slug,
      tags,
      thumbnail {
        url
      },
      mp4 {
        url
      },
      backgroundImage {
        url
      }
    }
  }
`;
    const accountQuery = external_graphql_request_.gql`
  query {
    account(where: {
      id: "cl3kdhutocj6b0dup1k9nbeun"
    }) {
      username,
      avatar {
        url
      }
    }
  }
`;
    const data = await client.request(videosQuery);
    const videos = data.videos;
    const accountData = await client.request(accountQuery);
    const account = accountData.account;
    return {
        props: {
            videos,
            account
        }
    };
};
function Home({ videos: videos1 , account  }) {
    const randomVideo = (videos)=>{
        const abc = Math.floor(Math.random() * videos.length);
        console.log("test" + abc);
    };
    const unSeenVideos = (videos)=>{
        return videos.filter((video)=>video.seen == false || video.seen == null
        );
    };
    const promo = ()=>{
        const video = randomVideo(videos1);
        console.log(video);
    };
    promo();
    randomVideo(videos1);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Disney Clone"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_NavBar, {
                account: account
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "app",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "main-video",
                        style: {
                            backgroundImage: "url(" + videos1[4].backgroundImage.url + ")"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "main-video-wrapper",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "main-video-info",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "POPULAR DISNEY MOVIE!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "video-title",
                                        children: videos1[4]?.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "video-tags",
                                        children: videos1[4]?.tags.join(", ")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "video-description",
                                        children: videos1[4]?.description
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: `/video/${videos1[4].slug}`,
                                        className: "watch-now",
                                        children: "MOVIE DETAILS"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "video-feed",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Section, {
                            genre: "Movies",
                            videos: videos1
                        })
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,675], () => (__webpack_exec__(868)));
module.exports = __webpack_exports__;

})();